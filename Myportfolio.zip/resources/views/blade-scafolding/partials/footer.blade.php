
    <div class="card-body CardBody">
        <div class="card-title">
            Got a Questione
            <i class="far fa-question-circle"></i>
            <a href="#" class="btn btn-light ">
                <?php
                echo "Mail Service"
                ?>
            </a>
            <!--Links directing to Public Profiles-->
            <div class="box boxx">
                <a href="https://soundcloud.com/tonie22"> <i class="fab fa-soundcloud" alt="To Soundcloud"></i></a>
                <a href="https://github.com/mino-cmd"> <i class="fab fa-github-alt" alt="To GitHub"></i></a>
            </div>
        </div>
    </div>
</div>

<footer class="page-footer">
    <div class="footer-copyright text-center py-3">@2020 copyright
    </div>

</footer>