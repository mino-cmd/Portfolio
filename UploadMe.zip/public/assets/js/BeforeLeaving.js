function myFunction() {
    alert("Hi :) we are leaving to LiveStream ⏺  \n\n Https://www.SeceretSaucee.com");
}
