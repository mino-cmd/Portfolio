// Wait for window load
$(window).load(function() {
    // Animate loader off screen
    $("#loader").animate({
        top: -200
    }, 1500);
});