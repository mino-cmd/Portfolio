<html>
<table>
    <?php for ($i = 10; $i <= 50; $i++) {
        echo "<button style='border: 1px black'><hr>\n Hello World";
    }
    ?>
</table>

</html>