@include('blade-scafolding.partials.FooterHead')
<!--*********************************-->
<footer class="page-footer">
    <div class="movetheButton text-center">

        <a href="mailto:adiatwork@outlook.com?subject=&body=" class="btn btn-dark ContactButton">
            <?php
            echo " Got a Questione ? Write me :"
            ?>
        </a>
        <div class="footer-copyright text-center" style="color: darkkhaki">
            @2020 copyrights

        </div>
    </div>
</footer>