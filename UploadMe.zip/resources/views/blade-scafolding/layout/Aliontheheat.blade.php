@include('blade-scafolding.partials.ExtendsRedirects')

<body>
    {{--    SELFi --}}
    {{-- @include('blade-scafolding.layout.Selfi2') --}}
    {{--    SELFi --}}
    <div class="col-2 position-absolute MyPageRedirects">
        <h3 class="text-light">
            <code>Livestream</code>
        </h3>
        <a href="https://www.Aliontheheat.com/" target="_blank" rel="import">
            <button onClick="myFunction()" type="button" class="btn btn-dark ButtonRedirect">
                <!--Ali on the heat dot com-->
                https://www.Secretsaucee.com
                <!--Ali on the heat dot com-->
            </button>
        </a>
        <div class="SwitchButtonDiv">
            {{--    *****************--}}
            {{--    Paging To project page --}}
            @include('blade-scafolding.layout.Paging2')
        </div>

    </div>