@include('blade-scafolding.partials.ExtendPaging')
<hr />
<label class="Checky2" id="CheckCheck" onclick="clickinner2(this);">
    <!--suppress JSUnresolvedFunction -->
    <input type="checkbox" checked data-toggle="toggle" data-size="sm" data-on="Live stream and Projects"
        data-off="home page" data-onstyle="light" data-offstyle="dark">
</label>