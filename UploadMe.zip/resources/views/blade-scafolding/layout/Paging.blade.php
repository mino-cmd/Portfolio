@include('blade-scafolding.partials.ExtendPaging')
<label class="Checky" id="CheckCheck" onclick="clickinner(this);">
    <!--suppress JSUnresolvedFunction -->
    <input type="checkbox" checked data-toggle="toggle" data-size="sm" data-onstyle="light" data-offstyle="dark"
        data-on="switch page" data-off="Pp.Ls" />
</label>