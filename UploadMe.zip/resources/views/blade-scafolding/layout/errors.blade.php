<!DOCTYPE html>
<html lang="en">

<head>
    <title>Page not found - 404</title>
</head>

<body>
<div style="font-family: 'Raleway', sans-serif;color: red;">
    @php
        echo "The page your looking for is not available";
    @endphp
</div>
</body>

</html>