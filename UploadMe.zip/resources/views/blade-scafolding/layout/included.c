#include <stdio.h>
#include <string.h>

int main()
{
    /* code */

    int number;

    number = 25;

    printf("%d", number);

    return 0;
}
