@include('blade-scafolding.partials.Extends_MUSIC_ITEMS')
<!--suppress HtmlDeprecatedAttribute -->
<body>
{{----}}
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/842404039&color=%235c645c&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/vhs2000" title="VHS 2000" target="_blank"
                   style="color: #cccccc; text-decoration: none;">VHS 2000</a> · <a
                        href="https://soundcloud.com/vhs2000/futurept2" title="Future.pt2 🍭🍭🍭" target="_blank"
                        style="color: #cccccc; text-decoration: none;">Future.pt2 🍭🍭🍭</a></div>
            {{--*********A SOUNDCLOUD CONTENT***********--}}{{--*********A SOUNDCLOUD CONTENT***********--}}
        </div>
        <div class="col-md-4">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/813348229&color=%235c645c&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/vhs2000" title="VHS 2000" target="_blank"
                   style="color: #cccccc; text-decoration: none;">VHS 2000</a> · <a
                        href="https://soundcloud.com/vhs2000/alibeats-break-down"
                        title="AliBeats 🔥🔥🔥BREAK - DOWN🔥🔥🔥" target="_blank"
                        style="color: #cccccc; text-decoration: none;">AliBeats 🔥🔥🔥BREAK - DOWN🔥🔥🔥</a>
                {{--*********A SOUNDCLOUD CONTENT***********--}}{{--*********A SOUNDCLOUD CONTENT***********--}}
            </div>
        </div>
        <div class="col-md-4">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/802206379&color=%23111411&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/vhs2000" title="VHS 2000" target="_blank"
                   style="color: #cccccc; text-decoration: none;">VHS 2000</a> · <a
                        href="https://soundcloud.com/vhs2000/0419-toniexxii" title="04.19 Toniexxii"
                        target="_blank" style="color: #cccccc; text-decoration: none;">04.19 Toniexxii</a>
                {{--*********A SOUNDCLOUD CONTENT***********--}}{{--*********A SOUNDCLOUD CONTENT***********--}}
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/864291724&color=%23111411&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/vhs2000" title="VHS 2000" target="_blank"
                   style="color: #cccccc; text-decoration: none;">VHS 2000</a> · <a
                        href="https://soundcloud.com/vhs2000/salsa-ali-beats" title="SALSA- Ali beats"
                        target="_blank"
                        style="color: #cccccc; text-decoration: none;">SALSA- Ali beats</a>
                {{--*********A SOUNDCLOUD CONTENT***********--}}{{--*********A SOUNDCLOUD CONTENT***********--}}
            </div>
        </div>
        <div class="col-md-4">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/864895789&color=%235c645c&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/vhs2000" title="VHS 2000" target="_blank"
                   style="color: #cccccc; text-decoration: none;">VHS 2000</a> · <a
                        href="https://soundcloud.com/vhs2000/alibeats-hit-maker"
                        title="AliBeats - HIT-Maker"
                        target="_blank" style="color: #cccccc; text-decoration: none;">AliBeats -
                    HIT-Maker</a>
                {{--*********A SOUNDCLOUD CONTENT***********--}}{{--*********A SOUNDCLOUD CONTENT***********--}}
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/791443015&color=%235c645c&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/vhs2000" title="VHS 2000" target="_blank"
                   style="color: #cccccc; text-decoration: none;">VHS 2000</a> · <a
                        href="https://soundcloud.com/vhs2000/upset" title="Line" target="_blank"
                        style="color: #cccccc; text-decoration: none;">Line</a>
                {{--*********A SOUNDCLOUD CONTENT***********--}}{{--*********A SOUNDCLOUD CONTENT***********--}}
            </div>
        </div>
        <div class="col-md-6">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/210720618&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/tonie22" title="Tonie XXII &lt;🚀&gt;" target="_blank"
                   style="color: #cccccc; text-decoration: none;">Tonie XXII &lt;🚀&gt;</a> · <a
                        href="https://soundcloud.com/tonie22/1-son-its-all-in-vintage-mother-ep"
                        title="[MOTHER EP] #1 Son its all in Vintage" target="_blank"
                        style="color: #cccccc; text-decoration: none;">[MOTHER EP] #1 Son its all in Vintage</a></div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay"
                    src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/227516020&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>
            <div style="font-size: 10px; color: #cccccc;line-break: anywhere;word-break: normal;overflow: hidden;white-space: nowrap;text-overflow: ellipsis; font-family: Interstate,Lucida Grande,Lucida Sans Unicode,Lucida Sans,Garuda,Verdana,Tahoma,sans-serif;font-weight: 100;">
                <a href="https://soundcloud.com/tonie22" title="Tonie XXII &lt;🚀&gt;" target="_blank"
                   style="color: #cccccc; text-decoration: none;">Tonie XXII &lt;🚀&gt;</a> · <a
                        href="https://soundcloud.com/tonie22/denya-okhra-glory-box-cover-home-session-thank-you"
                        title="REMIX Denya Okhra - Glory Box Cover" target="_blank"
                        style="color: #cccccc; text-decoration: none;">REMIX Denya Okhra - Glory Box Cover</a></div>
        </div>
    </div>
    {{----}}

</div>

</body>
