@include('blade-scafolding.partials.ExtendsRedirects')

<body>

    <div class="col-2 position-absolute MyPageRedirects2">
        <a href="/home" target="_blank" rel="import">
            <button type="button" class="btn btn-light ButtonRedirect">
                <!--GO TO THE MusicGrid-->
                👷‍♂️
                <code class="Color_beneth_text" style="display: block">back home </code>

                <!--GO TO THE MusicGrid-->
            </button>
        </a>
</body>