@include('blade-scafolding.partials.ExtendJumbotronVideo')


<div class="jumbotron jumbotron-fluid" style="background-color: transparent;">

    <div class="container text-light">
        <h3 class="text-danger">C C# Java & PHP, and the Path is still Very Long.. </h3>
    </div>
    <div id="ChangeVideoOpacity">
        <video id="video-background" style="position: relative;width: 50%; left: 10%" preload muted autoplay loop>
            <!--suppress HtmlUnknownTarget -->
            <source src="/assets/video/Video%20Cutter_16_8_22_2_18.mp4" type="video/mp4">
        </video>
        <div class="container text-light">
            <p>... and just like this website, my skills are not quite perfect yet!, but with the chance
                to hire me to work
                together, would open opportunities for Us both</p>
        </div>

    </div>
</div>