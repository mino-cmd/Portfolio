@include('blade-scafolding.partials.Selfitether')
<a href="https://github.com/mino-cmd/">
    <h6 class="text-light">Github</h6>

    <div class="thumbex position-absolute">
        <div class="thumbnail">

            <img src="/assets/images/Selfi2.jpeg" alt="Selfi of Developer" />
        </div>
    </div>
</a>