<link href="/assets/css/Osteopage.css" rel="stylesheet" />
{{--<link href="/public/assets/css/OLD__MedQuer.css" rel="stylesheet" />--}}