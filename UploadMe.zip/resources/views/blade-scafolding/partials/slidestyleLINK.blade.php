<link rel="stylesheet" href="/assets/css/slidestyle.css"/>
<link rel="stylesheet" href="/assets/css/TheSlideEffect.css"/>
