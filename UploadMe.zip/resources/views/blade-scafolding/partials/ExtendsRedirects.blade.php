<link href="/assets/css/RedirectPagesStyle.css" rel="stylesheet"/>
<script src="/assets/js/BeforeLeaving.js"></script>