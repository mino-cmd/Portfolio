<link href="/assets/css/moto.css" rel="stylesheet" />
<script src="/assets/js/loadertwo.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
