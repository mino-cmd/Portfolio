<?php
$ProducerA = "Ali";
$ProducerB = "Tonie22";
?>
<?php
echo "Producers :"?><a href="https://soundcloud.com/ali-adi-675675042" target="_blank"> <i style="color: darkkhaki"
        class="fab fa-soundcloud" alt="To Soundcloud"></i></a>
<?php
echo $ProducerA;
?> <?php echo "" ?>
<?php echo "&"?><a href="https://soundcloud.com/tonie22" target="_blank"> <i style="color: darkkhaki"
        class="fab fa-soundcloud" alt="To Soundcloud"></i></a>
<?php
echo $ProducerB
?>
@include('blade-scafolding.layout.RedirectsHome')