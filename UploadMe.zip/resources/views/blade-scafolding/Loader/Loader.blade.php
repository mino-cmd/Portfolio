@include('blade-scafolding.partials.ExtendCssOfLOADER')
@include('blade-scafolding.partials.head')
<body>
<div class="loader-wrapper">
    <span class="loader"><span class="loader-inner"></span></span>
</div>
</body>
